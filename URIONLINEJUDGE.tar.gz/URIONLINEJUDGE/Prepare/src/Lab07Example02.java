import java.util.*;

public class Lab07Example02 {

	public static void main(String[] args) {
		int y, m, d;
		Scanner sc = new Scanner(System.in);

		System.out.print("Year: ");
		y = sc.nextInt();

		System.out.print("Month: ");
		m = sc.nextInt();

		d = getDaysOfMonth(y, m);
		System.out.println("Number of Days: " + d);
	}

	static int getDaysOfMonth(int y, int m) {
		switch(m) {
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 2:
			return isLeapYear(y) ? 29 : 28 ;
		}
			
		return 0;
	}

	static boolean isLeapYear(int y) {
		return (y % 400  == 0 || y % 4 == 0 && y % 100 != 0);
	}
}
