import java.util.*;

public class URISampleTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		x = sc.nextInt();

		for (int i = 1; i < 27; i = i += 4) {
			for (int j = i; j <= i + 2; j++) {
					System.out.print(j + " ");
			}
			System.out.println("PUM");
		}
	}
}
