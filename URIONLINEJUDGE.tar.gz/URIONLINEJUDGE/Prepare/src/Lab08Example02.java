import java.util.Scanner;

public class Lab08Example02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int y, m, d;
		while(true) {
			System.out.print("Year " );
			if(!sc.hasNextInt()) {
				break;
			}
			y = sc.nextInt();
			System.out.print("Month " );
			if(!sc.hasNextInt()) {
				break;
			}
			m = sc.nextInt();
			
			d = getDays(y, m);
			System.out.println("Number of days: " + d);
			
		}
	}
	
	private static int getDays(int y, int m) {
		int [] days = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		if(m != 2) {
			return days[m - 1];
		}
		return isLeapYear(y) ? 29: 28;
	}
	
	static boolean isLeapYear(int y) {
		return (y % 400 == 0 || y % 4 == 0 && y % 100 != 0);
	}
}
