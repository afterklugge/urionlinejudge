import java.util.*;

public class Lab07Example01 {

	public static void main(String[] args) {
		int a = 0, b = 0, c = 0;
		Scanner sc = new Scanner(System.in);
		System.out.print("Your coordinate: ");
		a = sc.nextInt();

		System.out.print("Coordinate of 1st point: ");
		b = sc.nextInt();

		System.out.print("Coordinate of 2nd point: ");
		c = sc.nextInt();

		int x = abs(a - b);
		int y = abs(a - c);

		if (x < y) {
			System.out.println("1st point is closer." + " Distance " + x);
		} else if (x > y) {
			System.out.println("2nd point is closer." + " Distance " + y);
		} else {
			System.out.println("No data");
		}
	}

	static int abs(int n) {
		int r = n;
		if (r < 0) {
			r = -r;
		}
		return r;
	}

}
