import java.util.Scanner;
public class Lab08Example04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		boolean[] isCovered = new boolean[99]; // false
		
		int number = sc.nextInt();
		while(number != 0) {
			isCovered[number - 1] = true;
		}

	}

}
