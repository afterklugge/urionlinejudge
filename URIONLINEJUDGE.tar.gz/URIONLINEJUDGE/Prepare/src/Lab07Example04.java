import java.util.*;
public class Lab07Example04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a, b;
		
		System.out.print("A = ");
		a = sc.nextInt();
		
		System.out.print("B = ");
		b = sc.nextInt();
		
		int d = gdc(a, b);
		System.out.printf("GCD(%d, %d) = %d", a, b, d);

	}
	
	static int gdc(int a, int b) {
		if(a == 0 && b == 0) {
			throw new IllegalArgumentException("GCD(0, 0) is not defined.");
			
		}
		if (a == 0) {
			return b;
		}
		if (b == 0) {
			return a;
		}
		int d = Math.min(a, b);
		while(a % d != 0 || b % d != 0) {
			d--;
		}
		return d;
	}

}
