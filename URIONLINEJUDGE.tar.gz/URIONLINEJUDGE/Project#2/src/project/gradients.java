package project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class gradients extends JFrame {
	String title = "Graphics Template";
	Color background = Color.BLACK;

	void draw(Graphics g) {
		// your code...
		final int N = 9; // количество блоков
		int width = getSize().width; // ширина экрана
		int height = getSize().height; // высота экрана

		int b = (width - 200) / N; // отступ и ломтик каждого
		double k = 510.0 / b; // RGB 255 цветов делим на

		for (int i = 0; i < N; i++) { // Для количества ломтиков
			int start = i * b + 100; // Работаем с началом блока (+100 эт оотступ)
			for (int j = 0; j < b / 2; j++) { // этот for для цвета, конкретно для каждого блока. От темного до
												// насыщенного и наоборот
				g.setColor(new Color((int) (k * j), 0, 0)); // Выбираем красный цвет и пишем под нее формулу
				g.drawLine(start + j, 70, start + j, height - 70);
			}
			for (int j = b / 2; j < b; j++) {
				g.setColor(new Color((int) (k * (b - 1 - j)), 0, 0)); // От насыщенного к темному, -1 потому что убираем
																		// по 1 оттенку
				g.drawLine(start + j, 70, start + j, height - 70);

			}

		}
	}

	public gradients() {
		setTitle(title);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		DrawPanel panel = new DrawPanel();

		panel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				System.exit(0);
			}
		});

		add(panel);

		setUndecorated(true);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);
	}

	public static void main(String[] args) {
		new gradients();
	}

	class DrawPanel extends JPanel {
		public DrawPanel() {
			setBackground(background);
			setFocusable(true);
			requestFocusInWindow();
			setDoubleBuffered(true);
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			draw(g);
		}
	}
}