package project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class ProjectDraw1 extends JFrame {
	String title = "Graphics Template";
	Color background = Color.BLACK;

	void draw(Graphics g) {
		// your code...
		Random rnd = new Random();
		int w = getWidth();
		int h = getHeight();
		int n = 2000;
		int c = 255;

		int maxR = h / 8;
		for (int z = 0; z < n; z++) {
			int r = rnd.nextInt(maxR);
			double alpha = 2 * Math.PI * rnd.nextDouble();
			int x = (int) (w / 2 + r * Math.cos(alpha));
			int y = (int) (h / 2 + r * Math.sin(alpha));
			g.setColor(new Color(c, 0, 0));
			g.drawLine(w / 2, h / 2, x, y);
			c = rnd.nextInt(256);

		}
	}

public gradients() {
setTitle(title);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

DrawPanel panel = new DrawPanel();

panel.addKeyListener(new KeyAdapter() {
@Override
public void keyPressed(KeyEvent e) {
System.exit(0);
}
});

add(panel);

setUndecorated(true);
setExtendedState(JFrame.MAXIMIZED_BOTH);
setVisible(true);
}

	public static void main(String[] args) {
		new gradients();
	}

	class DrawPanel extends JPanel {
		public DrawPanel() {
			setBackground(background);
			setFocusable(true);
			requestFocusInWindow();
			setDoubleBuffered(true);
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			draw(g);
		}
	}
}