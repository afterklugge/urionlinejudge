import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class MovingCircle extends JFrame {
	String title = "Animation Template";
	Color background = Color.BLUE;
	int delay = 10;

	// Your variables...
	int xSun;
	int ySun;
	int rSun;
	
	int xEarth;
	int yEarth;
	int rEarth;
	
	int r;
	double a; // Радианная  мера
	double da;
	
	int w;
	int h;
	void start() {
        // your code...
		w = getWidth();
		h = getHight();
		
		xSun = w / 2; // Центр экрана
		ySun = h / 2;
		rSun = 100;
		r = 200;
		
		xEarth = xSun + r;
		yEarth = ySun;
		rEarth = 50;
	}

	void update() {
        // your code...
		g.setColor(Color.YELLOW);
		g.filloval(xSun - rSun, ySun - rSun, 2 * rSun, 2 * rSun);
		
		g.setColor(Color.BLUE);
		g.filloval(xEarth - rEarth, yEarth - rEarth, 2 * rEarth, 2 * rEarth);
	}

	void draw(Graphics g) {
        // your code...
	}

	public void AnimationTemplate() {
		setTitle(title);
		setLocationRelativeTo(null);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		DrawPanel panel = new DrawPanel();

		panel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				System.exit(0);
			}
		});

		add(panel);

		javax.swing.Timer timer = new javax.swing.Timer(delay, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				update();
				repaint();
			}
		});

		setUndecorated(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);

        try { Thread.sleep(500); } catch (InterruptedException e) {}
        
		start();
		
		timer.start();
	}

	public static void main(String[] args) {
		new AnimationTemplate();
	}

	class DrawPanel extends JPanel {
		public DrawPanel() {
			setBackground(background);
			setFocusable(true);
			requestFocusInWindow();
			setDoubleBuffered(true);
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			draw(g);
		}
	}
}