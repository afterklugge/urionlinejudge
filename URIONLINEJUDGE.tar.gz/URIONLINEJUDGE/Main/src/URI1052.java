import java.util.Scanner;
public class URI1052 {

	public static void main(String[] args) {
		int x;
		Scanner sc = new Scanner(System.in);
		x = sc.nextInt();
		
		if (x == 1) {
			System.out.println("January\n");
		}
		else if (x == 2) {
			System.out.println("February\n");
		}
		else if (x == 3) {
			System.out.println("March\n");
		}
		else if (x == 4) {
			System.out.println("April\n");
		}
		else if (x == 5) {
			System.out.println("May\n");
		}
		else if (x == 6) {
			System.out.println("June\n");
		}
		else if (x == 7) {
			System.out.println("July\n");
		}
		else if (x == 8) {
			System.out.println("August\n");
		}
		else if (x == 9) {
			System.out.println("September\n");
		}
		else if (x == 10) {
			System.out.println("October\n");
		}
		else if (x == 11) {
			System.out.println("November\n");
		}
		else if (x == 12) {
			System.out.println("December\n");
		}
	}

}
