public class URI1059 {

	public static void main(String[] args) {
		for(int i = 2; i <= 100; i = i + 2) {
			System.out.println(i);
		}
	}
}
