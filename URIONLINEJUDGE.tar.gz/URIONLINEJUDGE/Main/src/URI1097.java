
public class URI1097 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, j, k;
		for (i = 1, j = 7; i <= 9; i = i + 2) {
			for (int l = i, k = j; k1 >= (j - 2); j--) {
				System.out.printf("I=%d J=%d\n", i, k);
			}
		}
	}
}