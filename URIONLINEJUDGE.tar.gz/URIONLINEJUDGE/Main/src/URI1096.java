
public class URI1096 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i, j;
		for (i = 1; i <= 9; i = i + 2) {
			for (j = 7; j >= 5; j--) {
				System.out.printf("I=%d J=%d\n", i, j);
			}

		}
	}
}