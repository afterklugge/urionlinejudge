import java.util.Scanner;
public class URI1061 {

	public static void main(String[] args) {
	}
}
